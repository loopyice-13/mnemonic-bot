"""
wallet.py — BIP39 mnemonic generation + BIP44 HD wallet derivation
Supports: Ethereum, Bitcoin (3 formats), BNB Smart Chain, Solana
"""

from __future__ import annotations

from mnemonic import Mnemonic
from bip_utils import (
    Bip39MnemonicValidator,
    Bip39SeedGenerator,
    Bip44,
    Bip44Coins,
    Bip44Changes,
    Bip49,
    Bip49Coins,
    Bip84,
    Bip84Coins,
)
from solders.keypair import Keypair as SolanaKeypair
import nacl.signing
import hashlib
import hmac
import struct


class WalletDeriver:
    """Generate BIP39 mnemonics and derive multi-chain addresses."""

    def __init__(self):
        self._mnemo = Mnemonic("english")

    # ── Mnemonic helpers ──────────────────────────────────────────────────────

    def generate_mnemonic(self, word_count: int = 12) -> str:
        """Generate a cryptographically random BIP39 mnemonic."""
        strength = {12: 128, 24: 256}[word_count]
        return self._mnemo.generate(strength=strength)

    def is_valid_mnemonic(self, phrase: str) -> bool:
        """Validate BIP39 mnemonic (wordlist + checksum)."""
        return Bip39MnemonicValidator().IsValid(phrase)

    # ── Master seed ───────────────────────────────────────────────────────────

    def _seed_bytes(self, mnemonic: str) -> bytes:
        return Bip39SeedGenerator(mnemonic).Generate()

    # ── EVM chains (Ethereum / BNB) ───────────────────────────────────────────

    def _evm_address(self, mnemonic: str) -> str:
        seed = self._seed_bytes(mnemonic)
        bip44_ctx = Bip44.FromSeed(seed, Bip44Coins.ETHEREUM)
        acc = (
            bip44_ctx
            .Purpose()
            .Coin()
            .Account(0)
            .Change(Bip44Changes.CHAIN_EXT)
            .AddressIndex(0)
        )
        return acc.PublicKey().ToAddress()

    # ── Bitcoin ───────────────────────────────────────────────────────────────

    def _btc_legacy(self, mnemonic: str) -> str:
        """P2PKH  m/44'/0'/0'/0/0"""
        seed = self._seed_bytes(mnemonic)
        ctx = (
            Bip44.FromSeed(seed, Bip44Coins.BITCOIN)
            .Purpose().Coin().Account(0)
            .Change(Bip44Changes.CHAIN_EXT).AddressIndex(0)
        )
        return ctx.PublicKey().ToAddress()

    def _btc_segwit(self, mnemonic: str) -> str:
        """P2SH-P2WPKH  m/49'/0'/0'/0/0"""
        seed = self._seed_bytes(mnemonic)
        ctx = (
            Bip49.FromSeed(seed, Bip49Coins.BITCOIN)
            .Purpose().Coin().Account(0)
            .Change(Bip44Changes.CHAIN_EXT).AddressIndex(0)
        )
        return ctx.PublicKey().ToAddress()

    def _btc_native(self, mnemonic: str) -> str:
        """P2WPKH (bech32)  m/84'/0'/0'/0/0"""
        seed = self._seed_bytes(mnemonic)
        ctx = (
            Bip84.FromSeed(seed, Bip84Coins.BITCOIN)
            .Purpose().Coin().Account(0)
            .Change(Bip44Changes.CHAIN_EXT).AddressIndex(0)
        )
        return ctx.PublicKey().ToAddress()

    # ── Solana ────────────────────────────────────────────────────────────────

    def _solana_address(self, mnemonic: str) -> str:
        """
        Derive Solana address via SLIP-0010 ed25519 path m/44'/501'/0'/0'
        using pure Python (no solders required).
        """
        seed = self._seed_bytes(mnemonic)
        private_key = _slip10_ed25519_derive(seed, [0x8000002C, 0x800001F5, 0x80000000, 0x80000000])
        signing_key  = nacl.signing.SigningKey(private_key)
        verify_key   = signing_key.verify_key
        # Solana address = base58-encoded 32-byte public key
        return _base58_encode(bytes(verify_key))

    # ── Public API ────────────────────────────────────────────────────────────

    def derive_all(self, mnemonic: str) -> dict[str, str]:
        eth = self._evm_address(mnemonic)          # same path for ETH & BNB
        return {
            "ethereum":       eth,
            "bitcoin_legacy": self._btc_legacy(mnemonic),
            "bitcoin_segwit": self._btc_segwit(mnemonic),
            "bitcoin_native": self._btc_native(mnemonic),
            "bnb":            eth,                 # BNB uses Ethereum derivation path
            "solana":         self._solana_address(mnemonic),
        }


# ── SLIP-0010 ed25519 helpers ─────────────────────────────────────────────────

def _slip10_ed25519_derive(seed: bytes, path: list[int]) -> bytes:
    """Derive ed25519 private key following SLIP-0010."""
    key   = b"ed25519 seed"
    I     = hmac.new(key, seed, hashlib.sha512).digest()
    k_L, k_R = I[:32], I[32:]

    for index in path:
        data = b"\x00" + k_L + struct.pack(">I", index)
        I    = hmac.new(k_R, data, hashlib.sha512).digest()
        k_L, k_R = I[:32], I[32:]

    return k_L


_BASE58_CHARS = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"

def _base58_encode(data: bytes) -> str:
    n = int.from_bytes(data, "big")
    result = []
    while n:
        n, r = divmod(n, 58)
        result.append(_BASE58_CHARS[r])
    # leading zero bytes
    for byte in data:
        if byte == 0:
            result.append(_BASE58_CHARS[0])
        else:
            break
    return "".join(reversed(result))
