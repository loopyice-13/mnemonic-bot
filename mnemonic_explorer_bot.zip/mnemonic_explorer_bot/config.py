"""
config.py — Load environment variables and define constants.
"""

import os
from dotenv import load_dotenv

load_dotenv()

# ── Required ──────────────────────────────────────────────────────────────────
BOT_TOKEN: str = os.getenv("BOT_TOKEN", "")

# ── Optional API keys (higher rate limits when provided) ─────────────────────
ETHERSCAN_API_KEY:   str = os.getenv("ETHERSCAN_API_KEY",   "")
BSCSCAN_API_KEY:     str = os.getenv("BSCSCAN_API_KEY",     "")
BLOCKCHAIR_API_KEY:  str = os.getenv("BLOCKCHAIR_API_KEY",  "")

# ── Timeouts ──────────────────────────────────────────────────────────────────
REQUEST_TIMEOUT: int = 15  # seconds per API call

# ── Help text ─────────────────────────────────────────────────────────────────
HELP_TEXT = """
🧠 <b>Mnemonic Explorer Bot</b> — Help

This bot is an <b>educational tool</b> to understand how BIP39 seed phrases work
and how wallet addresses are derived across multiple blockchains using the
BIP44 HD derivation standard.

<b>Commands:</b>

/generate12 — Generate a random 12-word BIP39 seed phrase, derive wallet
addresses for Ethereum, Bitcoin (3 formats), BNB Smart Chain and Solana,
and show live on-chain balances.

/generate24 — Same as above but with a more secure 24-word seed phrase.

/check &lt;phrase&gt; — Analyse your own 12 or 24-word seed phrase.
Example: <code>/check word1 word2 word3 ... word12</code>

/help — Show this help message.

<b>Supported Chains &amp; Derivation Paths:</b>
• 🔷 Ethereum      → <code>m/44'/60'/0'/0/0</code>
• 🔶 Bitcoin P2PKH → <code>m/44'/0'/0'/0/0</code>
• 🟠 Bitcoin P2SH  → <code>m/49'/0'/0'/0/0</code>
• 🟡 Bitcoin bech32→ <code>m/84'/0'/0'/0/0</code>
• 🟢 BNB Chain     → <code>m/44'/60'/0'/0/0</code>
• 🟣 Solana        → <code>m/44'/501'/0'/0'</code>

<b>Balance Sources:</b>
Etherscan, Blockchair, BscScan, Solana RPC

⚠️ <b>Security Notice:</b>
<i>This tool is for learning purposes only.
Never enter a real seed phrase that holds funds into any bot or website.
Addresses with non-zero balances are logged locally for review.</i>
"""
