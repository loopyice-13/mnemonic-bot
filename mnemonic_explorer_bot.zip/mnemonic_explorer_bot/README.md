# 🧠 Mnemonic Explorer Bot

An educational Telegram bot for understanding **BIP39 seed phrases** and **HD wallet derivation** across multiple blockchains.

> ⚠️ **Educational use only.** Never share real seed phrases holding funds with any bot or website.

---

## Features

| Command | Description |
|---|---|
| `/start` | Welcome message |
| `/generate12` | Generate a random 12-word BIP39 seed phrase + derive addresses + live balances |
| `/generate24` | Same with a 24-word seed phrase |
| `/check <phrase>` | Check your own 12 or 24-word seed phrase |
| `/help` | Show all commands and learning info |

### Supported Chains

| Chain | Format | Derivation Path |
|---|---|---|
| Ethereum | EVM address | `m/44'/60'/0'/0/0` |
| Bitcoin Legacy | P2PKH (1xxx) | `m/44'/0'/0'/0/0` |
| Bitcoin SegWit | P2SH-P2WPKH (3xxx) | `m/49'/0'/0'/0/0` |
| Bitcoin Native | P2WPKH bech32 (bc1q) | `m/84'/0'/0'/0/0` |
| BNB Smart Chain | EVM address | `m/44'/60'/0'/0/0` |
| Solana | Base58 pubkey | `m/44'/501'/0'/0'` |

---

## Quick Start

### 1. Clone / Download

```bash
git clone https://github.com/you/mnemonic-explorer-bot.git
cd mnemonic-explorer-bot
```

### 2. Create a virtual environment

```bash
python3 -m venv venv
source venv/bin/activate        # Linux/macOS
venv\Scripts\activate.bat       # Windows
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Create your Telegram bot

1. Open Telegram and search for **@BotFather**
2. Send `/newbot` and follow the prompts
3. Copy the **API token** you receive

### 5. Configure environment

```bash
cp .env.example .env
nano .env            # or any text editor
```

Fill in at minimum:
```
BOT_TOKEN=1234567890:ABCdef...
```

#### Optional — Free API Keys (higher rate limits)

| Service | URL | Purpose |
|---|---|---|
| Etherscan | https://etherscan.io/myapikey | ETH balance |
| BscScan | https://bscscan.com/myapikey | BNB balance |
| Blockchair | https://blockchair.com/api | BTC balance |

The bot works without these keys but may hit rate limits under heavy use.

### 6. Run the bot

```bash
python bot.py
```

You should see:
```
2024-xx-xx xx:xx:xx | INFO | __main__ | 🚀 Mnemonic Explorer Bot is running…
```

---

## Running as a Service (Linux / systemd)

Create `/etc/systemd/system/mnemonicbot.service`:

```ini
[Unit]
Description=Mnemonic Explorer Telegram Bot
After=network.target

[Service]
Type=simple
User=your_user
WorkingDirectory=/path/to/mnemonic-explorer-bot
ExecStart=/path/to/mnemonic-explorer-bot/venv/bin/python bot.py
Restart=always
RestartSec=5
EnvironmentFile=/path/to/mnemonic-explorer-bot/.env

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl daemon-reload
sudo systemctl enable mnemonicbot
sudo systemctl start mnemonicbot
sudo systemctl status mnemonicbot
```

---

## Running with Docker

```bash
# Build
docker build -t mnemonic-explorer-bot .

# Run
docker run -d \
  --name mnemonicbot \
  --env-file .env \
  --restart unless-stopped \
  -v $(pwd)/results.log:/app/results.log \
  mnemonic-explorer-bot
```

---

## Project Structure

```
mnemonic-explorer-bot/
├── bot.py            ← Main bot, command handlers
├── wallet.py         ← BIP39 + BIP44/49/84 + Solana derivation
├── balances.py       ← Async balance fetching from public APIs
├── config.py         ← Environment variables + help text
├── logger.py         ← Results logger (addresses with balance)
├── requirements.txt
├── Dockerfile
├── .env.example
└── results.log       ← Auto-created when interesting results found
```

---

## How It Works

### BIP39 — Mnemonic Generation
A BIP39 mnemonic encodes entropy as human-readable words from a 2048-word list.
- 12 words = 128 bits of entropy
- 24 words = 256 bits of entropy

The mnemonic is hashed with PBKDF2-HMAC-SHA512 (2048 rounds) to produce a 512-bit **master seed**.

### BIP32 — HD Wallet Derivation
From the master seed, child keys are derived deterministically using a tree structure.
Each derivation path (`m/purpose'/coin'/account'/change/index`) uniquely identifies a key.

### BIP44/49/84 — Multi-coin Support
- BIP44 defines the `m/44'/coin_type'/...` path structure for legacy addresses
- BIP49 defines `m/49'/...` for P2SH-SegWit
- BIP84 defines `m/84'/...` for native bech32 SegWit

### SLIP-0010 — Solana (ed25519)
Solana uses ed25519 keys, derived via the SLIP-0010 standard which adapts BIP32 for ed25519 curves.

---

## results.log

When a derived address is found to have a non-zero balance, the full record is appended to `results.log`:

```
============================================================
TIMESTAMP : 2024-11-01 12:34:56 UTC
MNEMONIC  : word1 word2 word3 ...
ADDRESSES & BALANCES:
  ETH  (m/44'/60'/0'/0/0) : 0x123...  |  0.05 ETH  *** HAS BALANCE ***
  ...
```

---

## Disclaimer

This project is for **educational purposes only**.
- Do NOT use it to scan for wallets with real funds
- Do NOT share real seed phrases with any bot
- The developer is not responsible for misuse
