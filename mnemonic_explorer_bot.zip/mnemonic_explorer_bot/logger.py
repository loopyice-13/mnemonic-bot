"""
logger.py — Log interesting results (addresses with balance > 0) to results.log
"""

from __future__ import annotations

import logging
import os
from datetime import datetime, timezone

log = logging.getLogger(__name__)


class ResultsLogger:
    """Append wallet results with non-zero balances to a log file."""

    def __init__(self, filepath: str = "results.log"):
        self.filepath = filepath

    def _has_balance(self, balances: dict[str, str]) -> bool:
        for val in balances.values():
            try:
                if float(val) > 0:
                    return True
            except ValueError:
                pass
        return False

    def log_if_interesting(
        self,
        mnemonic: str,
        addresses: dict[str, str],
        balances: dict[str, str],
    ) -> None:
        """Write to results.log only when at least one chain has a non-zero balance."""
        if not self._has_balance(balances):
            return

        ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
        sep = "=" * 60

        lines = [
            sep,
            f"TIMESTAMP : {ts}",
            f"MNEMONIC  : {mnemonic}",
            "",
            "ADDRESSES & BALANCES:",
        ]

        chain_labels = {
            "ethereum":       "ETH  (m/44'/60'/0'/0/0) ",
            "bitcoin_legacy": "BTC Legacy (m/44'/0'/0'/0/0) ",
            "bitcoin_segwit": "BTC SegWit (m/49'/0'/0'/0/0) ",
            "bitcoin_native": "BTC Native (m/84'/0'/0'/0/0) ",
            "bnb":            "BNB  (m/44'/60'/0'/0/0) ",
            "solana":         "SOL  (m/44'/501'/0'/0') ",
        }

        symbols = {
            "ethereum": "ETH", "bitcoin_legacy": "BTC", "bitcoin_segwit": "BTC",
            "bitcoin_native": "BTC", "bnb": "BNB", "solana": "SOL",
        }

        for key, label in chain_labels.items():
            addr = addresses.get(key, "N/A")
            bal  = balances.get(key, "0")
            sym  = symbols[key]
            marker = "  *** HAS BALANCE ***" if float(bal or 0) > 0 else ""
            lines.append(f"  {label}: {addr}  |  {bal} {sym}{marker}")

        lines += ["", ""]

        try:
            with open(self.filepath, "a", encoding="utf-8") as f:
                f.write("\n".join(lines))
            log.info("💰 Interesting result logged to %s", self.filepath)
        except OSError as exc:
            log.error("Failed to write results.log: %s", exc)
