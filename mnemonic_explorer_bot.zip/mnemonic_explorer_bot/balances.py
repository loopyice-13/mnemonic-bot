"""
balances.py — Async balance fetching from public blockchain explorers.

APIs used (all free, no key required for basic queries):
  Ethereum   → Etherscan  (key recommended but has free tier)
  Bitcoin    → Blockchair
  BNB Chain  → BscScan    (key recommended but has free tier)
  Solana     → Solscan public API
"""

from __future__ import annotations

import asyncio
import logging
from typing import Optional

import aiohttp

from config import (
    ETHERSCAN_API_KEY,
    BSCSCAN_API_KEY,
    BLOCKCHAIR_API_KEY,
    REQUEST_TIMEOUT,
)

log = logging.getLogger(__name__)


class BalanceFetcher:
    """Fetch native token balances for multiple chains concurrently."""

    # ── Internal helpers ──────────────────────────────────────────────────────

    async def _get(self, session: aiohttp.ClientSession, url: str, params: dict = None) -> Optional[dict]:
        try:
            async with session.get(url, params=params, timeout=aiohttp.ClientTimeout(total=REQUEST_TIMEOUT)) as resp:
                if resp.status == 200:
                    return await resp.json(content_type=None)
        except Exception as exc:
            log.warning("HTTP error fetching %s: %s", url, exc)
        return None

    # ── Per-chain fetchers ────────────────────────────────────────────────────

    async def _eth_balance(self, session: aiohttp.ClientSession, address: str) -> str:
        params = {
            "module":  "account",
            "action":  "balance",
            "address": address,
            "tag":     "latest",
        }
        if ETHERSCAN_API_KEY:
            params["apikey"] = ETHERSCAN_API_KEY

        data = await self._get(session, "https://api.etherscan.io/api", params)
        if data and data.get("status") == "1":
            wei = int(data["result"])
            return f"{wei / 1e18:.6f}"
        return "0.000000"

    async def _btc_balance(self, session: aiohttp.ClientSession, addresses: list[str]) -> dict[str, str]:
        """Fetch all three BTC address formats in one Blockchair call."""
        addr_str = ",".join(addresses)
        url = f"https://api.blockchair.com/bitcoin/dashboards/addresses/{addr_str}"
        params = {}
        if BLOCKCHAIR_API_KEY:
            params["key"] = BLOCKCHAIR_API_KEY

        data = await self._get(session, url, params)
        result: dict[str, str] = {a: "0.00000000" for a in addresses}

        if data and "data" in data:
            combined = data["data"].get("addresses", {})
            for addr in addresses:
                info = combined.get(addr)
                if info:
                    satoshis = info.get("balance", 0)
                    result[addr] = f"{satoshis / 1e8:.8f}"
        return result

    async def _bnb_balance(self, session: aiohttp.ClientSession, address: str) -> str:
        params = {
            "module":  "account",
            "action":  "balance",
            "address": address,
            "tag":     "latest",
        }
        if BSCSCAN_API_KEY:
            params["apikey"] = BSCSCAN_API_KEY

        data = await self._get(session, "https://api.bscscan.com/api", params)
        if data and data.get("status") == "1":
            wei = int(data["result"])
            return f"{wei / 1e18:.6f}"
        return "0.000000"

    async def _sol_balance(self, session: aiohttp.ClientSession, address: str) -> str:
        url = "https://api.mainnet-beta.solana.com"
        payload = {
            "jsonrpc": "2.0",
            "id":      1,
            "method":  "getBalance",
            "params":  [address],
        }
        try:
            async with session.post(
                url,
                json=payload,
                timeout=aiohttp.ClientTimeout(total=REQUEST_TIMEOUT)
            ) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    lamports = data.get("result", {}).get("value", 0)
                    return f"{lamports / 1e9:.6f}"
        except Exception as exc:
            log.warning("Solana RPC error: %s", exc)
        return "0.000000"

    # ── Public API ────────────────────────────────────────────────────────────

    async def fetch_all(self, addresses: dict[str, str]) -> dict[str, str]:
        """
        Concurrently fetch all balances.
        `addresses` keys: ethereum, bitcoin_legacy, bitcoin_segwit, bitcoin_native, bnb, solana
        """
        async with aiohttp.ClientSession(
            headers={"User-Agent": "MnemonicExplorerBot/1.0 (educational)"}
        ) as session:

            btc_addrs = [
                addresses["bitcoin_legacy"],
                addresses["bitcoin_segwit"],
                addresses["bitcoin_native"],
            ]

            eth_task = self._eth_balance(session, addresses["ethereum"])
            btc_task = self._btc_balance(session, btc_addrs)
            bnb_task = self._bnb_balance(session, addresses["bnb"])
            sol_task = self._sol_balance(session, addresses["solana"])

            eth_bal, btc_bals, bnb_bal, sol_bal = await asyncio.gather(
                eth_task, btc_task, bnb_task, sol_task
            )

        return {
            "ethereum":       eth_bal,
            "bitcoin_legacy": btc_bals.get(addresses["bitcoin_legacy"], "0.00000000"),
            "bitcoin_segwit": btc_bals.get(addresses["bitcoin_segwit"], "0.00000000"),
            "bitcoin_native": btc_bals.get(addresses["bitcoin_native"], "0.00000000"),
            "bnb":            bnb_bal,
            "solana":         sol_bal,
        }
